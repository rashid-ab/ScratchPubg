
    <p>{{$content['text']}}</p>